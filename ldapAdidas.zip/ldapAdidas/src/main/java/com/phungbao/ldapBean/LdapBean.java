package com.phungbao.ldapBean;

public class LdapBean {
	// 
}
