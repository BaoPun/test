package com.phungbao.ldapControllers;

import java.net.URI;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpSession;

@RestController
public class LdapActionController {
	@PostMapping("/login")
	public ResponseEntity<String> confirmLoginCredentials(HttpSession session, @RequestParam MultiValueMap<String, String> paramMap){
		
		// Retrieve the 2 inputs
		String uid = paramMap.getFirst("userid");
		String password = paramMap.getFirst("password");
		
		// Create a new URI based on the success or failure of the login info
		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(URI.create("/ldapAdidas"));
		
		System.out.println("{domain}\\{username}: " + uid);
		System.out.println("password: " + password);
		
		return new ResponseEntity<String>(headers, HttpStatus.FOUND);
	}
}
