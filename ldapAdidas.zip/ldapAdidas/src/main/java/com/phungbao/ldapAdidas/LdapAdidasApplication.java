package com.phungbao.ldapAdidas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LdapAdidasApplication {

	public static void main(String[] args) {
		SpringApplication.run(LdapAdidasApplication.class, args);
	}

}
