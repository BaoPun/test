package com.phungbao.ldapAdidas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LdapAdidasApplicationTests {

	@Test
	void contextLoads() {
	}

}
